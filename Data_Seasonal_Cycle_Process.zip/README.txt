seasonal_range_depend_on_GRACE06: 
The P, ET, Runoff for these file. 

grace_data_river_seasonal_cycle:
14 river-basins seasonal cycle (2003-2014)

CMIP6_ds-p-e-r: 
Model's TWSA, P, ET, Runoff seasnonal cycle. Also calculated model accumulated PER based on model TWSA.

ds-p-e-r_calculate_with_obs_per:
The observation accumulated PER based on each model TWSA seasonal cycle. 